const PAUSE_MS = 700;
let activeTarget=null, wrap=null, debTimer=null, lastText="";
function todayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;}
function quickHash(s){let h=0,i,chr;if(!s)return"0";for(i=0;i<s.length;i++){chr=s.charCodeAt(i);h=(h<<5)-h+chr;h|=0}return String(h)}
async function getState(){
  const [local,sync]=await Promise.all([chrome.storage.local.get(["dailyUsed","dailyDate","mutedSites","lastHashes"]),chrome.storage.sync.get(["premiumEnabled","dailyLimit","backendURL"])]);
  return{
    dailyUsed:local.dailyUsed??0,
    dailyDate:local.dailyDate??todayKey(),
    mutedSites:local.mutedSites??{},
    lastHashes:local.lastHashes??[],
    premiumEnabled:!!sync.premiumEnabled,
    dailyLimit:Number.isFinite(sync.dailyLimit)?Math.max(1,sync.dailyLimit):30,
    backendURL:(sync.backendURL||"http://localhost:8787").replace(/\/+$/,"")
  };
}
async function incUsageOnce(hash,premiumEnabled){
  const local=await chrome.storage.local.get(["dailyUsed","dailyDate","lastHashes"]);
  const dkey=todayKey();
  if(local.dailyDate!==dkey){await chrome.storage.local.set({dailyDate:dkey,dailyUsed:0,lastHashes:[]});local.dailyDate=dkey;local.dailyUsed=0;local.lastHashes=[];}
  if(premiumEnabled)return{dailyUsed:local.dailyUsed,limited:false};
  const lastHashes=local.lastHashes||[];
  if(lastHashes.includes(hash))return{dailyUsed:local.dailyUsed,limited:false};
  const next=(local.dailyUsed||0)+1; const newHashes=[hash,...lastHashes].slice(0,50);
  await chrome.storage.local.set({dailyUsed:next,lastHashes:newHashes});
  const {dailyLimit}=await chrome.storage.sync.get(["dailyLimit"]);
  return{dailyUsed:next,limited:next>=(Number.isFinite(dailyLimit)?dailyLimit:30)};
}
function isPromptLike(el){const big=el.offsetHeight>=32&&(el.tagName==="TEXTAREA"||el.isContentEditable);const multiline=(el.tagName==="TEXTAREA")||el.isContentEditable;return big||multiline;}
function ensureOverlay(target,compact=false){
  if(!wrap){
    wrap=document.createElement("div"); wrap.className="pm-wrap";
    const card=document.createElement("div"); card.className="pm-card";
    card.innerHTML=`
      <div>
        <div class="pm-meter"><div class="pm-fill"></div></div>
        <div class="pm-note"></div>
      </div>
      <div class="pm-ctr">
        <span class="pm-score">—</span>
        <span class="pm-chip pm-quota">0/0</span>
        <span class="pm-link pm-toggle">silenciar</span>
      </div>`;
    wrap.appendChild(card);
    document.documentElement.appendChild(wrap);
    card.querySelector(".pm-toggle").addEventListener("click", async (e)=>{
      e.stopPropagation();
      const {mutedSites}=await chrome.storage.local.get(["mutedSites"]);
      const host=location.hostname||"unknown"; const next={...(mutedSites||{})};
      if(next[host]) delete next[host]; else next[host]=true;
      await chrome.storage.local.set({mutedSites:next});
      card.querySelector(".pm-toggle").textContent = next[host] ? "reativar" : "silenciar";
      if(next[host]) wrap.classList.add("pm-hidden"); else { wrap.classList.remove("pm-hidden"); positionOverlay(activeTarget); }
    });
  }
  wrap.classList.toggle("pm-compact",!!compact); positionOverlay(target);
}
function positionOverlay(target){
  if(!wrap||!target)return;
  const r=target.getBoundingClientRect();
  wrap.style.top=`${(window.scrollY||document.documentElement.scrollTop)+r.bottom+8}px`;
  wrap.style.left=`${(window.scrollX||document.documentElement.scrollLeft)+r.left}px`;
}
function getText(el){
  if(!el)return"";
  if(el.tagName==="TEXTAREA"|| (el.tagName==="INPUT" && /text|search|email|url|password|tel/.test(el.type))) return el.value||"";
  if(el.isContentEditable) return el.innerText||el.textContent||"";
  return "";
}
async function analyzeWithAI(text){
  const st=await getState();
  const body=JSON.stringify({ text, site: location.hostname, lang: navigator.language || "pt-BR" });
  const url=`${st.backendURL}/analyze`;
  try{
    const res=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body,cache:"no-store"});
    if(!res.ok) throw new Error("HTTP "+res.status);
    const data=await res.json();
    return {ok:true,data};
  }catch(err){ return {ok:false,error:String(err)}; }
}
async function updateUI({score,tip},usage,premium){
  if(!wrap)return;
  const fill=wrap.querySelector(".pm-fill"); const note=wrap.querySelector(".pm-note"); const scoreEl=wrap.querySelector(".pm-score"); const quota=wrap.querySelector(".pm-quota"); const toggle=wrap.querySelector(".pm-toggle");
  const pct=Math.max(0,Math.min(100,Math.round((Number(score)||0)/10*100))); fill.style.width=pct+"%";
  scoreEl.textContent=Number.isFinite(score)?Number(score).toFixed(1):"—"; note.textContent=tip||"";
  quota.textContent=premium?"∞":`${usage.dailyUsed}/${usage.dailyLimit}`; quota.classList.toggle("pm-muted",!!premium);
  const {mutedSites={}}=await chrome.storage.local.get(["mutedSites"]); const host=location.hostname||"unknown"; toggle.textContent=mutedSites[host]?"reativar":"silenciar";
}
async function handleEvaluate(target){
  const st=await getState(); const text=getText(target); if(text===lastText)return; lastText=text;
  const h=quickHash(text.slice(0,800)); const usage=await incUsageOnce(h,st.premiumEnabled); const limited=!st.premiumEnabled && usage.limited;
  let score=null, tip="";
  if(limited){ tip="Limite diário do modo grátis atingido. Volte amanhã ou desbloqueie ilimitado."; }
  else {
    const ai=await analyzeWithAI(text);
    if(ai.ok){ score=ai.data.score; tip=ai.data.tip; }
    else { score=null; tip="Falha momentânea na IA. Tente novamente em instantes."; }
  }
  await updateUI({score,tip},{dailyUsed:usage.dailyUsed,dailyLimit:st.dailyLimit},st.premiumEnabled);
}
document.addEventListener("focusin", async (e)=>{
  const el=e.target; if(!el)return;
  if(!(el.tagName==="TEXTAREA" || (el.tagName==="INPUT" && /text|search|email|url|password|tel/.test(el.type)) || el.isContentEditable)) return;
  if(!isPromptLike(el)) return;
  const {mutedSites}=await chrome.storage.local.get(["mutedSites"]);
  if((mutedSites||{})[location.hostname]) { if(wrap)wrap.classList.add("pm-hidden"); return; }
  activeTarget=el; ensureOverlay(el, el.offsetHeight<80 || el.offsetWidth<300); wrap.classList.remove("pm-hidden"); lastText=""; handleEvaluate(el);
});
["input","keyup","paste"].forEach(evt=>{
  document.addEventListener(evt,(e)=>{ if(!activeTarget || e.target!==activeTarget) return; clearTimeout(debTimer); debTimer=setTimeout(()=>handleEvaluate(activeTarget),PAUSE_MS); }, true);
});
window.addEventListener("scroll",()=>positionOverlay(activeTarget),true);
window.addEventListener("resize",()=>positionOverlay(activeTarget),true);