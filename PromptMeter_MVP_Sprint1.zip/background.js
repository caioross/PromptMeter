chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(["backendURL","dailyLimit","premiumEnabled"], (s) => {
    const init = {};
    if (!s.backendURL) init.backendURL = "http://localhost:8787"; // ajuste depois
    if (!Number.isFinite(s.dailyLimit)) init.dailyLimit = 30;
    if (typeof s.premiumEnabled !== "boolean") init.premiumEnabled = false;
    if (Object.keys(init).length) chrome.storage.sync.set(init);
  });
});